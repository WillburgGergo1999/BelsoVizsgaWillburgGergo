export{};
//1.feladat
function Rng (alsoHatar:number, felsoHatar:number):number{
    let generaltSzam:number;   
        generaltSzam=Math.round(Math.random()*(felsoHatar-alsoHatar))+alsoHatar;
        let oszto:number=0;
        for(let i=1;i<=generaltSzam;i++)
        {
            if(generaltSzam%i==0){
                oszto++;
            }
        }       
    
    return generaltSzam;
}


//2.feladat
function TombGenerator(meret:number, alsoHatar:number, felsoHatar:number){
    let generaltSzam:number;
    while(meret)
    {
    generaltSzam=Math.round(Math.random()*(felsoHatar-alsoHatar));
        let oszto:number=0;
        for(let i=1;i<=generaltSzam;i++)
        {
            if(generaltSzam%i==0){
                oszto++;
            }
        }
    }       
}

//3.feladat
function Duplazo()

//4.feladat

function PrimekSzama(hatarEgy:number,hatarKetto:number):number{
    let also:number;
    let felso:number;
    if (hatarEgy < hatarKetto) {
        also = hatarEgy;
        felso = hatarKetto;
    }
    else {
        also = hatarKetto;
        felso = hatarEgy;
    }
    let probalkozasokSzama:number=0;
    let sikeresGeneralas:boolean=false;
    let generaltSzam:number;
    do{
        generaltSzam=Math.round(Math.random()*(felso-also)+also);
        probalkozasokSzama++;
        let oszto:number=0;
        for(let i=1;i<=generaltSzam;i++)
        {
            if(generaltSzam%i==0){
                oszto++;
            }
        }
        if(oszto==2)
        {
            sikeresGeneralas=true;
        }
    }while(sikeresGeneralas==false && probalkozasokSzama<100)
    return generaltSzam;
}