"use strict";
exports.__esModule = true;
//1.feladat
function Rng(alsoHatar, felsoHatar) {
    var generaltSzam;
    do {
        generaltSzam = Math.round(Math.random() * (felsoHatar - alsoHatar));
        var oszto = 0;
        for (var i = 1; i <= generaltSzam; i++) {
            if (generaltSzam % i == 0) {
                oszto++;
            }
        }
    } while ();
    return generaltSzam;
}
//2.feladat
function TombGenerator(meret, alsoHatar, felsoHatar) {
    var generaltSzam;
    generaltSzam = Math.round(Math.random() * (felsoHatar - alsoHatar));
    var oszto = 0;
    for (var i = 1; i <= generaltSzam; i++) {
        if (generaltSzam % i == 0) {
            oszto++;
        }
    }
}
//4.feladat
function PrimekSzama(hatarEgy, hatarKetto) {
    var also;
    var felso;
    if (hatarEgy < hatarKetto) {
        also = hatarEgy;
        felso = hatarKetto;
    }
    else {
        also = hatarKetto;
        felso = hatarEgy;
    }
    var probalkozasokSzama = 0;
    var sikeresGeneralas = false;
    var generaltSzam;
    do {
        generaltSzam = Math.round(Math.random() * (felso - also) + also);
        probalkozasokSzama++;
        var oszto = 0;
        for (var i = 1; i <= generaltSzam; i++) {
            if (generaltSzam % i == 0) {
                oszto++;
            }
        }
        if (oszto == 2) {
            sikeresGeneralas = true;
        }
    } while (sikeresGeneralas == false && probalkozasokSzama < 100);
    return generaltSzam;
}
